# RNA-Protein Concordance and Subtype Discrimination in Breast Cancer: a Multi-Omics Analysis

Python pipeline that integrates matched transcriptomic (RNA-seq) and proteomic (mass spectrometry)
profiles of breast tumors from the public CPTAC breast cancer cohort (hosted on LinkedOmics).

## Questions
1. How well do RNA and protein levels agree, gene by gene, across patients?
2. Which pathways are enriched among high- vs low-concordance genes?
3. Do RNA only, protein only, or the combined data separate breast cancer subtypes better?

## Data (public, not included in this repository)
Download into `data/raw/` from <https://linkedomics.org/data_download/CPTAC-BRCA/>:
| File | Content |
|---|---|
| `HS_CPTAC_BRCA_2018_RNA_GENE.cct` | RNA-seq, gene level (log2 FPKM, median-normalised per portal) |
| `HS_CPTAC_BRCA_2018_Proteome_Ratio_Norm_gene_Median.cct` | Proteome, gene level (TMT log2 ratio) |
| `HS_CPTAC_BRCA_2018_CLI.tsi` | Clinical attributes incl. subtype |

Check the portal's citation/usage statement and cite the original CPTAC publication and LinkedOmics.

## Setup
```
python -m venv venv
venv\Scripts\activate          # macOS/Linux: source venv/bin/activate
pip install -r requirements.txt
```

## Run
```
python tools/make_synthetic_data.py          # optional dry run on FAKE data
set BRCA_MODE=synthetic                      # macOS/Linux: export BRCA_MODE=synthetic
python run_all.py
set BRCA_MODE=real                           # macOS/Linux: export BRCA_MODE=real
python src/01_inspect.py                     # real data: inspect first
python run_all.py                            # whole pipeline
```
If `01_inspect.py` says no subtype column was found, set `SUBTYPE_COLUMN` in `src/config.py`.
Stage 6 (pathway enrichment) needs internet access (Enrichr web service).

## Structure
```
data/raw/         downloaded input files (not committed)
data/processed/   cleaned & matched tables written by stage 2
src/              config.py, utils.py, 01_..06_ analysis scripts
tools/            synthetic-data generator for dry runs
results/          CSV / TXT outputs
figures/          PNG figures (300 dpi)
docs/             theory + viva guide (PDF)
run_all.py        runs every stage in order
```

## Pipeline
inspect -> clean & match samples/genes -> QC -> RNA-protein correlation (Spearman + BH-FDR)
-> PCA / k-means / heatmaps (RNA, protein, RNA+protein) -> logistic-regression subtype classifier
(stratified CV) -> pathway enrichment (Enrichr via gseapy).

## Results
Fill in only after running on the real data (see `docs/` guide, "Results log").

## Limitations
- ~100 samples: ML estimates are noisy. - PAM50 subtypes are defined from RNA expression, so RNA
is expected to separate them well (partial circularity). - Association, not causation.
- Concatenation is the simplest form of integration. - Synthetic data is for code testing only.

## Future scope
Phosphoproteome layer; copy-number/mutation layers; MOFA/DIABLO/SNF integration; survival analysis;
independent validation cohort; protein-protein interaction network (STRING).

## Reproducibility
Fixed random seed (`RANDOM_STATE=42`), pinned minimum versions in `requirements.txt`, all
parameters in `src/config.py`.

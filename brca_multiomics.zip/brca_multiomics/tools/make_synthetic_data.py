"""
Creates FAKE data in data/synthetic/ with the same file names/format as the
real files, so you can test the pipeline before downloading anything.
THESE NUMBERS ARE RANDOM - never report results from synthetic data.
Usage:  python tools/make_synthetic_data.py
        BRCA_MODE=synthetic python run_all.py      (Windows: set BRCA_MODE=synthetic)
"""
import sys
from pathlib import Path

import numpy as np
import pandas as pd

sys.path.insert(0, str(Path(__file__).resolve().parents[1] / "src"))
import os
os.environ["BRCA_MODE"] = "synthetic"
import config  # noqa: E402

rng = np.random.default_rng(0)
config.RAW_DIR.mkdir(parents=True, exist_ok=True)

n = 120
subtypes = np.array(["Basal", "Her2", "LumA", "LumB"])
labels = rng.choice(subtypes, size=n, p=[0.2, 0.15, 0.4, 0.25])
samples = [f"X01BR{i:03d}" for i in range(1, n + 1)]

markers = ["ESR1", "ERBB2", "GATA3", "TP53", "PGR", "MKI67"]
genes = markers + [f"GENE{i:04d}" for i in range(1, 2995)]
g = len(genes)

# subtype signal in the first 400 genes
effect = np.zeros((g, len(subtypes)))
effect[:400] = rng.normal(0, 1.2, size=(400, len(subtypes)))
group_idx = np.array([list(subtypes).index(l) for l in labels])
signal = effect[:, group_idx]                                  # genes x samples

rna = signal + rng.normal(0, 1, size=(g, n))
coupling = rng.uniform(0, 1, size=g)                            # how RNA-like protein is
prot_full = coupling[:, None] * rna + (1 - coupling[:, None]) * rng.normal(0, 1.5, size=(g, n))

prot_idx = np.arange(0, 2000)                                   # protein measured for 2000 genes
prot = prot_full[prot_idx]
miss_rate = rng.choice([0.02, 0.1, 0.6], size=len(prot_idx), p=[0.6, 0.3, 0.1])
prot = np.where(rng.random(prot.shape) < miss_rate[:, None], np.nan, prot)

pd.DataFrame(rna, index=genes, columns=samples).rename_axis("attrib_name").to_csv(config.RNA_FILE, sep="\t")
pd.DataFrame(prot, index=[genes[i] for i in prot_idx], columns=samples).rename_axis("attrib_name").to_csv(config.PROT_FILE, sep="\t")

# clinical stored attributes x samples (tests auto-transpose)
cli = pd.DataFrame({"PAM50": labels, "Age": rng.integers(30, 85, n)}, index=samples).T
cli.rename_axis("attrib_name").to_csv(config.CLIN_FILE, sep="\t")
print(f"Synthetic files written to {config.RAW_DIR}")

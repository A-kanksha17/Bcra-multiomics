"""Run the whole pipeline: python run_all.py   (set BRCA_MODE=synthetic for a dry run)"""
import subprocess
import sys
from pathlib import Path

SRC = Path(__file__).resolve().parent / "src"
STEPS = [("01_inspect.py", True), ("02_clean_match.py", True), ("03_correlation.py", True),
         ("04_pca_clustering.py", True), ("05_classification.py", True),
         ("06_pathway_enrichment.py", False)]          # (script, required?)

for script, required in STEPS:
    print(f"\n{'=' * 70}\nRUNNING {script}\n{'=' * 70}")
    code = subprocess.call([sys.executable, str(SRC / script)])
    if code != 0:
        if required:
            sys.exit(f"\n{script} failed (exit code {code}). Fix the error above and re-run.")
        print(f"[warn] optional step {script} failed; continuing.")
print("\nAll done. See results/ and figures/.")

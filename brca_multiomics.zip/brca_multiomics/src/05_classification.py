"""
Stage 5 - Supervised classification of subtype (logistic regression, stratified
k-fold cross-validation) using RNA only, Protein only and RNA+Protein features.
"""
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import (accuracy_score, classification_report, confusion_matrix,
                             f1_score, precision_score, recall_score)
from sklearn.model_selection import StratifiedKFold
from sklearn.pipeline import make_pipeline
from sklearn.preprocessing import StandardScaler

import config
import utils

config.ensure_dirs()
sets = utils.build_feature_sets()
subtype = utils.load_subtypes().reindex(sets["RNA"].index)

counts = subtype.value_counts()
keep_classes = counts[counts >= config.MIN_CLASS_SIZE].index
dropped = counts[counts < config.MIN_CLASS_SIZE]
if len(dropped):
    print(f"[warn] dropping subtypes with < {config.MIN_CLASS_SIZE} samples: {dict(dropped)}")
mask = subtype.isin(keep_classes)
y = subtype[mask]
classes = sorted(y.unique())
n_splits = int(min(config.CV_FOLDS, y.value_counts().min()))
print(f"Samples used: {len(y)} | classes: {classes} | CV folds: {n_splits}")
skf = StratifiedKFold(n_splits=n_splits, shuffle=True, random_state=config.RANDOM_STATE)

rows, reports, cms = [], [], {}
for name, X_all in sets.items():
    X = X_all.loc[mask]
    model = make_pipeline(StandardScaler(),
                          LogisticRegression(max_iter=5000, C=1.0, class_weight="balanced"))
    pred = np.empty(len(y), dtype=object)
    fold_f1 = []
    for tr, te in skf.split(X, y):
        model.fit(X.iloc[tr], y.iloc[tr])
        p = model.predict(X.iloc[te])
        pred[te] = p
        fold_f1.append(f1_score(y.iloc[te], p, average="macro", zero_division=0))
    rows.append({
        "feature_set": name, "n_features": X.shape[1],
        "accuracy": accuracy_score(y, pred),
        "precision_macro": precision_score(y, pred, average="macro", zero_division=0),
        "recall_macro": recall_score(y, pred, average="macro", zero_division=0),
        "f1_macro": f1_score(y, pred, average="macro", zero_division=0),
        "f1_macro_fold_mean": np.mean(fold_f1), "f1_macro_fold_sd": np.std(fold_f1),
    })
    cms[name] = confusion_matrix(y, pred, labels=classes)
    reports.append(f"=== {name} ===\n" + classification_report(y, pred, zero_division=0))

metrics = pd.DataFrame(rows).round(3)
metrics.to_csv(config.RESULTS_DIR / "classification_metrics.csv", index=False)
(config.RESULTS_DIR / "classification_reports.txt").write_text("\n".join(reports), encoding="utf-8")
print("\n", metrics.to_string(index=False))

fig, ax = plt.subplots(figsize=(6, 4.2))
ax.bar(metrics["feature_set"], metrics["f1_macro_fold_mean"], yerr=metrics["f1_macro_fold_sd"],
       capsize=5, color=["#55A868", "#C44E52", "#8172B2"])
ax.set_ylabel("Macro F1 (mean +/- SD over CV folds)")
ax.set_title("Subtype classification by data layer")
ax.set_ylim(0, 1.05)
utils.save_fig(fig, "fig_classification_f1.png")

fig, axes = plt.subplots(1, 3, figsize=(16, 4.6))
for ax, (name, cm) in zip(axes, cms.items()):
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues", cbar=False, ax=ax,
                xticklabels=classes, yticklabels=classes)
    ax.set_title(name)
    ax.set_xlabel("Predicted")
    ax.set_ylabel("True")
fig.tight_layout()
utils.save_fig(fig, "fig_confusion_matrices.png")
print("\nStage 5 finished.")

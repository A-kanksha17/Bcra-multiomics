"""utils.py - helper functions shared by all analysis scripts."""
from pathlib import Path

import matplotlib
matplotlib.use("Agg")                      # draw to files, no pop-up windows
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns

import config


# ----------------------------------------------------------------- IDs / loading
def normalize_id(x):
    """Make sample IDs comparable: strip spaces, upper-case, drop a leading
    'X' that R adds in front of names that start with a digit."""
    s = str(x).strip().upper()
    if len(s) > 1 and s[0] == "X" and s[1].isdigit():
        s = s[1:]
    return s


def load_table(path):
    path = Path(path)
    if not path.exists():
        raise FileNotFoundError(
            f"Missing file: {path}\nDownload it from "
            "https://linkedomics.org/data_download/CPTAC-BRCA/ into data/raw/ "
            "(see README.md)."
        )
    df = pd.read_csv(path, sep="\t", index_col=0, low_memory=False)
    df.index = df.index.astype(str).str.strip()
    df.columns = df.columns.astype(str).str.strip()
    return df


def _clean_omics(df):
    df = df.apply(pd.to_numeric, errors="coerce")
    df.index = df.index.astype(str).str.strip().str.upper()
    df.columns = [normalize_id(c) for c in df.columns]
    df = df[~df.index.isin(["", "NAN"])]
    df = df.groupby(level=0).mean()                       # duplicate gene symbols -> mean
    df = df.loc[:, ~pd.Index(df.columns).duplicated()]    # duplicate samples -> keep first
    return df


def load_omics_pair():
    """Return (rna, protein), both as genes x samples, cleaned.
    Orientation is detected automatically: the axis whose labels overlap most
    between the two files is the gene axis."""
    rna = load_table(config.RNA_FILE)
    prot = load_table(config.PROT_FILE)
    col_overlap = len(set(rna.columns) & set(prot.columns))
    idx_overlap = len(set(rna.index) & set(prot.index))
    if col_overlap > idx_overlap:            # genes are columns -> transpose
        rna, prot = rna.T, prot.T
    return _clean_omics(rna), _clean_omics(prot)


def load_clinical(sample_ids):
    """Return clinical table as samples x attributes (auto-transposes)."""
    cli = load_table(config.CLIN_FILE)
    ids = set(sample_ids)
    col_ids = {normalize_id(c) for c in cli.columns}
    idx_ids = {normalize_id(i) for i in cli.index}
    if len(col_ids & ids) > len(idx_ids & ids):
        cli = cli.T
    cli.index = [normalize_id(i) for i in cli.index]
    cli = cli[~cli.index.duplicated()]
    cli.columns = [str(c).strip() for c in cli.columns]
    return cli


def find_subtype_column(cli):
    if config.SUBTYPE_COLUMN:
        if config.SUBTYPE_COLUMN not in cli.columns:
            raise KeyError(f"SUBTYPE_COLUMN='{config.SUBTYPE_COLUMN}' not in clinical columns.")
        return config.SUBTYPE_COLUMN
    for kw in config.SUBTYPE_KEYWORDS:
        cands = [c for c in cli.columns if kw.lower() in str(c).lower()]
        if cands:
            if len(cands) > 1:
                print(f"[warn] several columns match '{kw}': {cands}. Using '{cands[0]}'. "
                      "Set SUBTYPE_COLUMN in src/config.py to choose another.")
            return cands[0]
    raise ValueError(
        "No subtype column found automatically. Run 01_inspect.py, pick the "
        "right clinical column, and set SUBTYPE_COLUMN in src/config.py."
    )


# ------------------------------------------------------------- processed files
def load_processed(name):
    path = config.PROC_DIR / name
    if not path.exists():
        raise FileNotFoundError(f"{path} not found - run the earlier scripts first.")
    return pd.read_csv(path, index_col=0)


def load_subtypes():
    s = load_processed("subtype.csv")["subtype"]
    return s.where(s.notna())


# ----------------------------------------------------------------- statistics
def bh_fdr(pvals):
    """Benjamini-Hochberg false discovery rate (NaN-safe)."""
    p = np.asarray(pvals, dtype=float)
    out = np.full(p.shape, np.nan)
    ok = ~np.isnan(p)
    pv = p[ok]
    n = len(pv)
    if n == 0:
        return out
    order = np.argsort(pv)
    ranked = pv[order] * n / np.arange(1, n + 1)
    ranked = np.minimum.accumulate(ranked[::-1])[::-1]
    res = np.empty(n)
    res[order] = np.minimum(ranked, 1.0)
    out[ok] = res
    return out


def top_variable(df, n):
    """Names of the n genes (rows) with highest variance across samples."""
    n = min(n, df.shape[0])
    return df.var(axis=1).sort_values(ascending=False).index[:n]


def build_feature_sets():
    """Samples x features tables for RNA, Protein and combined (concatenated)."""
    rna = load_processed("rna_model.csv")
    prot = load_processed("prot_model.csv")
    rna_x = rna.loc[list(top_variable(rna, config.TOP_N_VARIABLE))].T
    prot_x = prot.loc[list(top_variable(prot, config.TOP_N_VARIABLE))].T
    comb = pd.concat([rna_x.add_prefix("RNA_"), prot_x.add_prefix("PROT_")], axis=1)
    return {"RNA": rna_x, "Protein": prot_x, "RNA+Protein": comb}


# ------------------------------------------------------------------- plotting
def subtype_colors(subtype):
    labels = sorted(subtype.dropna().unique())
    pal = sns.color_palette("Set1", n_colors=max(len(labels), 3))
    return {lab: pal[i] for i, lab in enumerate(labels)}


def color_series(subtype, cmap):
    return subtype.map(lambda v: cmap.get(v, (0.8, 0.8, 0.8)))


def save_fig(fig, name):
    path = config.FIG_DIR / name
    fig.savefig(path, dpi=300, bbox_inches="tight")
    plt.close(fig)
    print(f"  saved figure -> {path}")

"""
config.py - one place for every path and parameter used in the project.
Change values here, not inside the analysis scripts.

Run modes
---------
BRCA_MODE=real       (default) uses data/raw/ and writes to results/, figures/
BRCA_MODE=synthetic  uses data/synthetic/ (fake data for a dry run) and writes
                     to results_synthetic/, figures_synthetic/  so real and
                     fake outputs never mix.
"""
import os
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
MODE = os.environ.get("BRCA_MODE", "real").lower()
SUFFIX = "" if MODE == "real" else "_synthetic"

RAW_DIR = ROOT / "data" / ("raw" if MODE == "real" else "synthetic")
PROC_DIR = ROOT / "data" / f"processed{SUFFIX}"
RESULTS_DIR = ROOT / f"results{SUFFIX}"
FIG_DIR = ROOT / f"figures{SUFFIX}"

# ---- raw input files (LinkedOmics CPTAC-BRCA file names) -------------------
RNA_FILE = RAW_DIR / "HS_CPTAC_BRCA_2018_RNA_GENE.cct"
PROT_FILE = RAW_DIR / "HS_CPTAC_BRCA_2018_Proteome_Ratio_Norm_gene_Median.cct"
CLIN_FILE = RAW_DIR / "HS_CPTAC_BRCA_2018_CLI.tsi"

# ---- subtype label ----------------------------------------------------------
# Set SUBTYPE_COLUMN to the exact clinical column name once you have seen the
# output of 01_inspect.py. If None, the code searches for a column whose name
# contains one of the keywords below.
SUBTYPE_COLUMN = None
SUBTYPE_KEYWORDS = ["PAM50", "subtype"]

# ---- analysis parameters ----------------------------------------------------
RANDOM_STATE = 42
MIN_PAIRED = 30            # min samples with both RNA and protein to correlate a gene
MAX_MISSING_MODEL = 0.20   # genes with >20% missing values are excluded from PCA/ML
TOP_N_VARIABLE = 2000      # most variable genes kept per layer for PCA / ML
MIN_CLASS_SIZE = 5         # subtypes with fewer samples are dropped from ML
CV_FOLDS = 5
HIGH_RHO = 0.5             # "high concordance" threshold (Spearman rho)
LOW_RHO = 0.2              # "low concordance" threshold
N_ENRICH = 500             # genes per list for pathway enrichment
ENRICH_LIBRARIES = ["MSigDB_Hallmark_2020", "KEGG_2021_Human"]
MARKER_GENES = ["ESR1", "ERBB2", "GATA3", "TP53", "PGR", "MKI67"]


def ensure_dirs():
    for d in (PROC_DIR, RESULTS_DIR, FIG_DIR):
        d.mkdir(parents=True, exist_ok=True)

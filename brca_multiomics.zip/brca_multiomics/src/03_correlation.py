"""
Stage 3 - RNA-protein concordance (single-gene Spearman correlation across samples).

For every shared gene we ask: across patients, do tumors with higher RNA also
have higher protein? Output: results/rna_protein_correlation.csv plus figures.
"""
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from scipy import stats

import config
import utils

config.ensure_dirs()
rna = utils.load_processed("rna_matched.csv")
prot = utils.load_processed("prot_matched.csv")
subtype = utils.load_subtypes().reindex(rna.columns)

rv, pv = rna.values.astype(float), prot.values.astype(float)
rows = []
for i, gene in enumerate(rna.index):
    x, y = rv[i], pv[i]
    ok = ~np.isnan(x) & ~np.isnan(y)
    n = int(ok.sum())
    if n < config.MIN_PAIRED or np.std(x[ok]) == 0 or np.std(y[ok]) == 0:
        rows.append((gene, n, np.nan, np.nan))
        continue
    rho, p = stats.spearmanr(x[ok], y[ok])
    rows.append((gene, n, rho, p))

res = pd.DataFrame(rows, columns=["gene", "n_pairs", "spearman_rho", "p_value"]).set_index("gene")
res["fdr"] = utils.bh_fdr(res["p_value"].values)       # multiple-testing correction


def categorize(r):
    if np.isnan(r["spearman_rho"]):
        return "not_tested"
    if r["spearman_rho"] >= config.HIGH_RHO and r["fdr"] < 0.05:
        return "high"
    if r["spearman_rho"] < config.LOW_RHO:
        return "low"
    return "moderate"


res["category"] = res.apply(categorize, axis=1)
res = res.sort_values("spearman_rho", ascending=False)
res.to_csv(config.RESULTS_DIR / "rna_protein_correlation.csv")

tested = res.dropna(subset=["spearman_rho"])
summary = [
    f"Genes tested                     : {len(tested)}",
    f"Median Spearman rho              : {tested['spearman_rho'].median():.3f}",
    f"Genes with rho > 0 and FDR < 0.05: {((tested['spearman_rho'] > 0) & (tested['fdr'] < 0.05)).sum()} "
    f"({((tested['spearman_rho'] > 0) & (tested['fdr'] < 0.05)).mean():.1%})",
    f"High concordance (rho >= {config.HIGH_RHO}, FDR<0.05): {(res['category'] == 'high').sum()}",
    f"Low concordance  (rho <  {config.LOW_RHO})            : {(res['category'] == 'low').sum()}",
    "Top 10 genes by rho   : " + ", ".join(tested.index[:10]),
    "Bottom 10 genes by rho: " + ", ".join(tested.index[-10:]),
]
print("\n".join(summary))
(config.RESULTS_DIR / "correlation_summary.txt").write_text("\n".join(summary), encoding="utf-8")

# ---- Figure 1: histogram of correlations ------------------------------------
fig, ax = plt.subplots(figsize=(7, 4.5))
sns.histplot(tested["spearman_rho"], bins=50, color="#4C72B0", ax=ax)
ax.axvline(0, color="grey", ls=":")
ax.axvline(tested["spearman_rho"].median(), color="red", ls="--",
           label=f"median = {tested['spearman_rho'].median():.2f}")
ax.set_xlabel("Spearman correlation (RNA vs protein, across patients)")
ax.set_ylabel("Number of genes")
ax.set_title("RNA-protein concordance per gene")
ax.legend()
utils.save_fig(fig, "fig_rna_protein_correlation_hist.png")

# ---- Figure 2: example scatter plots ----------------------------------------
genes = [g for g in config.MARKER_GENES if g in tested.index]
for g in (tested.index[0], tested.index[-1]):             # best and worst gene
    if g not in genes:
        genes.append(g)
genes = genes[:8]
cmap = utils.subtype_colors(subtype)
cols = 4
nrows = int(np.ceil(len(genes) / cols))
fig, axes = plt.subplots(nrows, cols, figsize=(4 * cols, 3.6 * nrows), squeeze=False)
for ax in axes.ravel():
    ax.axis("off")
for ax, g in zip(axes.ravel(), genes):
    ax.axis("on")
    ax.scatter(rna.loc[g], prot.loc[g], c=list(utils.color_series(subtype, cmap)), s=22,
               edgecolor="none")
    ax.set_title(f"{g}  (rho = {tested.loc[g, 'spearman_rho']:.2f})", fontsize=10)
    ax.set_xlabel("RNA")
    ax.set_ylabel("Protein")
handles = [plt.Line2D([], [], marker="o", ls="", color=c, label=l) for l, c in cmap.items()]
if handles:
    fig.legend(handles=handles, loc="lower center", ncol=len(handles), title="Subtype")
fig.tight_layout(rect=(0, 0.06, 1, 1))
utils.save_fig(fig, "fig_rna_protein_scatter_examples.png")
print("\nStage 3 finished.")

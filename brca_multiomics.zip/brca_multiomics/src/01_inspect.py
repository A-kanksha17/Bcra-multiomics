"""
Stage 1 - Inspect the raw files.
Prints shapes, sample-ID overlap, missing values and the clinical columns,
and saves everything to results/inspection_report.txt.
Nothing is modified. Run this first and read the output carefully.
"""
import pandas as pd

import config
import utils

config.ensure_dirs()
lines = []


def say(msg=""):
    print(msg)
    lines.append(str(msg))


raw_rna = utils.load_table(config.RNA_FILE)
raw_prot = utils.load_table(config.PROT_FILE)
say(f"RNA file     as stored (rows x columns): {raw_rna.shape}")
say(f"Protein file as stored (rows x columns): {raw_prot.shape}")

rna, prot = utils.load_omics_pair()
say("\nAfter automatic orientation (genes x samples):")
say(f"  RNA     : {rna.shape[0]} genes x {rna.shape[1]} samples")
say(f"  Protein : {prot.shape[0]} genes x {prot.shape[1]} samples")

shared_samples = sorted(set(rna.columns) & set(prot.columns))
shared_genes = sorted(set(rna.index) & set(prot.index))
say(f"  Samples present in BOTH layers : {len(shared_samples)}")
say(f"  Genes present in BOTH layers   : {len(shared_genes)}")
say(f"  Example sample IDs: {shared_samples[:5]}")
say(f"  Example genes     : {shared_genes[:5]}")

say("\nMissing values (NaN):")
say(f"  RNA     : {rna.isna().sum().sum()} of {rna.size} cells ({rna.isna().mean().mean():.1%})")
say(f"  Protein : {prot.isna().sum().sum()} of {prot.size} cells ({prot.isna().mean().mean():.1%})")

say("\nValue ranges (should look like log-scale numbers):")
say(f"  RNA     min/median/max: {rna.min().min():.2f} / {rna.stack().median():.2f} / {rna.max().max():.2f}")
say(f"  Protein min/median/max: {prot.min().min():.2f} / {prot.stack().median():.2f} / {prot.max().max():.2f}")

cli = utils.load_clinical(shared_samples)
overlap = len(set(cli.index) & set(shared_samples))
say(f"\nClinical table (samples x attributes): {cli.shape}; "
    f"samples matching omics IDs: {overlap}")
say("Clinical columns:")
for c in cli.columns:
    say(f"  - {c}  ({cli[c].nunique()} unique values)")

try:
    col = utils.find_subtype_column(cli)
    say(f"\nSubtype column chosen: '{col}'")
    say(cli[col].value_counts(dropna=False).to_string())
except Exception as e:
    say(f"\n[ACTION NEEDED] {e}")

(config.RESULTS_DIR / "inspection_report.txt").write_text("\n".join(lines), encoding="utf-8")
say(f"\nReport saved to {config.RESULTS_DIR / 'inspection_report.txt'}")

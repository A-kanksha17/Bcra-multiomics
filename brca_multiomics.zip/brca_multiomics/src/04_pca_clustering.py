"""
Stage 4 - Exploratory analysis: PCA, k-means clustering, heatmaps.
Compares RNA only vs Protein only vs RNA+Protein (concatenated) for how well
the samples group by PAM50-type subtype.
"""
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import seaborn as sns
from sklearn.cluster import KMeans
from sklearn.decomposition import PCA
from sklearn.metrics import adjusted_rand_score, silhouette_score
from sklearn.preprocessing import StandardScaler

import config
import utils

config.ensure_dirs()
sets = utils.build_feature_sets()
subtype = utils.load_subtypes().reindex(sets["RNA"].index)
known = subtype.notna()
cmap = utils.subtype_colors(subtype)
k = subtype[known].nunique()
print(f"Samples with subtype: {known.sum()}  | subtypes: {sorted(cmap)}")

fig, axes = plt.subplots(1, 3, figsize=(16, 4.8))
rows, var_rows = [], []
for ax, (name, X) in zip(axes, sets.items()):
    Z = StandardScaler().fit_transform(X)                  # z-score each gene
    n_comp = min(10, Z.shape[0] - 1, Z.shape[1])
    pca = PCA(n_components=n_comp, random_state=config.RANDOM_STATE)
    pcs = pca.fit_transform(Z)
    ev = pca.explained_variance_ratio_
    var_rows.append({"layer": name, **{f"PC{i+1}": round(v, 4) for i, v in enumerate(ev)}})

    colors = utils.color_series(subtype, cmap)
    ax.scatter(pcs[:, 0], pcs[:, 1], c=list(colors), s=28, edgecolor="none")
    ax.set_xlabel(f"PC1 ({ev[0]:.1%} variance)")
    ax.set_ylabel(f"PC2 ({ev[1]:.1%} variance)")
    ax.set_title(f"{name}  ({X.shape[1]} features)")

    clusters = KMeans(n_clusters=k, n_init=20, random_state=config.RANDOM_STATE).fit_predict(pcs)
    ari = adjusted_rand_score(subtype[known], clusters[known.values])
    sil = silhouette_score(pcs[known.values], subtype[known]) if k > 1 else np.nan
    rows.append({"layer": name, "n_features": X.shape[1], "k": k,
                 "ARI_kmeans_vs_subtype": round(ari, 3),
                 "silhouette_of_subtypes": round(sil, 3)})

handles = [plt.Line2D([], [], marker="o", ls="", color=c, label=l) for l, c in cmap.items()]
fig.legend(handles=handles, loc="lower center", ncol=len(handles), title="Subtype")
fig.tight_layout(rect=(0, 0.1, 1, 1))
utils.save_fig(fig, "fig_pca_by_layer.png")

metrics = pd.DataFrame(rows)
metrics.to_csv(config.RESULTS_DIR / "clustering_metrics.csv", index=False)
pd.DataFrame(var_rows).to_csv(config.RESULTS_DIR / "pca_explained_variance.csv", index=False)
print("\n", metrics.to_string(index=False))

fig, axes = plt.subplots(1, 2, figsize=(9, 4))
for ax, col, title in zip(axes, ["ARI_kmeans_vs_subtype", "silhouette_of_subtypes"],
                          ["Adjusted Rand Index\n(k-means vs subtype)",
                           "Silhouette of subtype labels\n(in PCA space)"]):
    ax.bar(metrics["layer"], metrics[col], color=["#55A868", "#C44E52", "#8172B2"])
    ax.set_title(title)
    ax.axhline(0, color="black", lw=0.8)
    ax.tick_params(axis="x", rotation=15)
fig.tight_layout()
utils.save_fig(fig, "fig_subtype_separation_metrics.png")

# ---- heatmaps of the 40 most variable genes per layer ------------------------
col_colors = utils.color_series(subtype, cmap)
for name in ["RNA", "Protein"]:
    X = sets[name]
    top = X.var().sort_values(ascending=False).index[:40]
    g = sns.clustermap(X[top].T, z_score=0, cmap="vlag", center=0, figsize=(11, 9),
                       col_colors=col_colors.values.tolist(), xticklabels=False,
                       yticklabels=True)
    handles = [plt.Line2D([], [], marker="s", ls="", color=c, label=l) for l, c in cmap.items()]
    g.ax_heatmap.set_ylabel("")
    g.fig.legend(handles=handles, loc="center left", bbox_to_anchor=(1.0, 0.5), title="Subtype")
    g.fig.suptitle(f"Top 40 most variable genes - {name}", y=1.02)
    g.savefig(config.FIG_DIR / f"fig_heatmap_top40_{name.lower()}.png", dpi=300, bbox_inches="tight")
    plt.close(g.fig)
    print(f"  saved figure -> fig_heatmap_top40_{name.lower()}.png")
print("\nStage 4 finished.")

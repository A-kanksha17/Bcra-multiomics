"""
Stage 2 - Clean, match samples/genes, quality control.

Outputs (data/processed/):
  rna_matched.csv, prot_matched.csv   genes x samples, shared genes & samples, NaN kept
  rna_model.csv,  prot_model.csv      filtered (<=20% missing) + median-imputed, for PCA/ML
  subtype.csv                         one subtype label per sample
Outputs (results/, figures/): qc_summary.csv and two QC figures.
"""
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config
import utils

config.ensure_dirs()

rna, prot = utils.load_omics_pair()
n_rna_genes, n_prot_genes = rna.shape[0], prot.shape[0]

# ---- 1. keep only samples present in both layers (sample matching) ----------
shared_samples = sorted(set(rna.columns) & set(prot.columns))
if len(shared_samples) < 10:
    raise SystemExit(
        f"Only {len(shared_samples)} shared samples. Sample IDs probably differ between "
        "files - run 01_inspect.py and compare the example IDs.")
rna, prot = rna[shared_samples], prot[shared_samples]

# ---- 2. keep only genes present in both layers (feature matching) -----------
rna = rna.dropna(how="all")
prot = prot.dropna(how="all")
shared_genes = sorted(set(rna.index) & set(prot.index))
rna_m, prot_m = rna.loc[shared_genes], prot.loc[shared_genes]
rna_m.to_csv(config.PROC_DIR / "rna_matched.csv")
prot_m.to_csv(config.PROC_DIR / "prot_matched.csv")
print(f"Matched: {len(shared_samples)} samples, {len(shared_genes)} genes")

# ---- 3. missing-value filter + imputation for PCA / ML ---------------------
miss_rna = rna_m.isna().mean(axis=1)
miss_prot = prot_m.isna().mean(axis=1)
keep = (miss_rna <= config.MAX_MISSING_MODEL) & (miss_prot <= config.MAX_MISSING_MODEL)
rna_k, prot_k = rna_m.loc[keep], prot_m.loc[keep]


def impute_gene_median(df):
    """Fill each gene's missing values with that gene's median across samples."""
    return df.T.fillna(df.T.median()).T


rna_k, prot_k = impute_gene_median(rna_k), impute_gene_median(prot_k)
nonconst = (rna_k.var(axis=1) > 0) & (prot_k.var(axis=1) > 0)       # drop constant genes
rna_k, prot_k = rna_k.loc[nonconst], prot_k.loc[nonconst]
rna_k.to_csv(config.PROC_DIR / "rna_model.csv")
prot_k.to_csv(config.PROC_DIR / "prot_model.csv")
print(f"After missing-value filter (<= {config.MAX_MISSING_MODEL:.0%}) and variance filter: "
      f"{rna_k.shape[0]} genes kept for PCA / ML")

# ---- 4. QC summary + figures ------------------------------------------------
summary = pd.DataFrame({
    "item": ["RNA genes (raw)", "Protein genes (raw)", "Shared samples", "Shared genes",
             "Genes kept for PCA/ML", "Protein missing cells (shared genes), %",
             "RNA missing cells (shared genes), %"],
    "value": pd.Series([n_rna_genes, n_prot_genes, len(shared_samples), len(shared_genes),
                        rna_k.shape[0], round(100 * prot_m.isna().mean().mean(), 2),
                        round(100 * rna_m.isna().mean().mean(), 2)], dtype=object),
})
summary.to_csv(config.RESULTS_DIR / "qc_summary.csv", index=False)
print(summary.to_string(index=False))

fig, axes = plt.subplots(1, 2, figsize=(11, 4))
axes[0].hist(miss_prot, bins=30, color="#4C72B0", edgecolor="white")
axes[0].axvline(config.MAX_MISSING_MODEL, color="red", ls="--", label="filter threshold")
axes[0].set_xlabel("Fraction of samples with missing protein value (per gene)")
axes[0].set_ylabel("Number of genes")
axes[0].set_title("Protein missingness")
axes[0].legend()
labels = ["RNA raw", "Protein raw", "Shared", "Kept for\nPCA/ML"]
vals = [n_rna_genes, n_prot_genes, len(shared_genes), rna_k.shape[0]]
axes[1].bar(labels, vals, color=["#55A868", "#C44E52", "#8172B2", "#CCB974"])
for i, v in enumerate(vals):
    axes[1].text(i, v, str(v), ha="center", va="bottom")
axes[1].set_ylabel("Number of genes")
axes[1].set_title("Gene filtering steps")
fig.tight_layout()
utils.save_fig(fig, "qc_missingness_and_filtering.png")

rng = np.random.default_rng(config.RANDOM_STATE)
r_vals = rna_m.values.ravel()
p_vals = prot_m.values.ravel()
r_vals = r_vals[~np.isnan(r_vals)]
p_vals = p_vals[~np.isnan(p_vals)]
fig, axes = plt.subplots(1, 2, figsize=(11, 4))
axes[0].hist(rng.choice(r_vals, min(200000, len(r_vals)), replace=False), bins=60, color="#55A868")
axes[0].set_title("RNA values (matched genes)")
axes[0].set_xlabel("Expression value (log scale, as provided)")
axes[0].set_ylabel("Count")
axes[1].hist(rng.choice(p_vals, min(200000, len(p_vals)), replace=False), bins=60, color="#C44E52")
axes[1].set_title("Protein values (matched genes)")
axes[1].set_xlabel("log2 ratio (as provided)")
fig.tight_layout()
utils.save_fig(fig, "qc_value_distributions.png")

# ---- 5. subtype labels -------------------------------------------------------
cli = utils.load_clinical(shared_samples).reindex(shared_samples)
cli.to_csv(config.PROC_DIR / "clinical_matched.csv")
try:
    col = utils.find_subtype_column(cli)
except Exception as e:
    raise SystemExit(f"\n[ACTION NEEDED] {e}")
sub = cli[col].astype("string").str.strip()
sub = sub.mask(sub.isin(["", "NA", "N/A", "NAN", "nan", "None", "<NA>"]))
pd.DataFrame({"subtype": sub}).to_csv(config.PROC_DIR / "subtype.csv")
print(f"\nSubtype column used: '{col}'")
print(sub.value_counts(dropna=False).to_string())
print("\nStage 2 finished.")

"""
Stage 6 - Pathway enrichment of high- vs low-concordance genes (needs internet:
gseapy sends the gene lists to the Enrichr web service).
This stage is optional; if it fails the rest of the project is unaffected.
"""
import sys

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd

import config
import utils

config.ensure_dirs()
try:
    import gseapy as gp
except ImportError:
    print("[SKIPPED] gseapy is not installed: pip install gseapy")
    sys.exit(0)

res = pd.read_csv(config.RESULTS_DIR / "rna_protein_correlation.csv", index_col=0)
tested = res.dropna(subset=["spearman_rho"])
background = list(tested.index)

high = tested[(tested["fdr"] < 0.05)].sort_values("spearman_rho", ascending=False)
high_genes = list(high.index[:config.N_ENRICH])
low_genes = list(tested.sort_values("spearman_rho").index[:config.N_ENRICH])
print(f"High-concordance list: {len(high_genes)} genes | Low-concordance list: {len(low_genes)} genes")

all_out = []
for label, genes in [("high_concordance", high_genes), ("low_concordance", low_genes)]:
    if len(genes) < 10:
        print(f"[skip] {label}: fewer than 10 genes")
        continue
    try:
        try:
            enr = gp.enrichr(gene_list=genes, gene_sets=config.ENRICH_LIBRARIES,
                             organism="human", background=background, outdir=None)
        except Exception as e1:
            print(f"[info] enrichment with custom background failed ({e1}); retrying without")
            enr = gp.enrichr(gene_list=genes, gene_sets=config.ENRICH_LIBRARIES,
                             organism="human", outdir=None)
    except Exception as e:
        print(f"[SKIPPED] Enrichr failed for {label}: {e}\n"
              "Check your internet connection, or gseapy.get_library_name() for library names.")
        sys.exit(0)
    df = enr.results.copy()
    df["gene_list"] = label
    all_out.append(df)

if not all_out:
    sys.exit(0)
out = pd.concat(all_out, ignore_index=True)
out.to_csv(config.RESULTS_DIR / "pathway_enrichment_all.csv", index=False)

fig, axes = plt.subplots(1, 2, figsize=(15, 5.5))
for ax, label in zip(axes, ["high_concordance", "low_concordance"]):
    sub = out[(out["gene_list"] == label) & (out["Gene_set"] == config.ENRICH_LIBRARIES[0])]
    sub = sub.sort_values("Adjusted P-value").head(10).iloc[::-1]
    if sub.empty:
        ax.set_title(f"{label}: no terms")
        ax.axis("off")
        continue
    ax.barh(sub["Term"], -np.log10(sub["Adjusted P-value"].clip(lower=1e-300)), color="#4C72B0")
    ax.set_xlabel("-log10(adjusted p-value)")
    ax.set_title(f"{label.replace('_', ' ')} - {config.ENRICH_LIBRARIES[0]}")
fig.tight_layout()
utils.save_fig(fig, "fig_pathway_enrichment.png")
print("\nStage 6 finished.")
